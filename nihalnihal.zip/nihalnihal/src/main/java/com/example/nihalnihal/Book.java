package com.example.nihalnihal;

public class Book {
    private String bookName;
    private int bookID;

    public Book(int bookID, String bookName) {
        this.bookID = bookID;
        this.bookName = bookName;
    }
    public int getBookID() {
        return bookID;
    }
    public String getBookName() {
        return bookName;
    }
}
