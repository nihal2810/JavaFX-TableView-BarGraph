package com.example.nihalnihal;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Collector {
    public List<Book> databaseConnection() {
        List<Book> data = new ArrayList<>();
//using try catch method to prevent errors..
        try (Connection connection = new DatabaseConnector().connect();
             Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT book_id, book_name FROM book_info");

            while (resultSet.next()) {
                String bookName = resultSet.getString("bookName");
                int bookID = resultSet.getInt("bookID");
                data.add(new Book(bookID, bookName));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return data;
    }
}
