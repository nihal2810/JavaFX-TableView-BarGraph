package com.example.nihalnihal;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MainApplication extends Application {
    private Stage primaryStage;
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        this.primaryStage = stage;
        getBarGraph();
    }
// database connection..
    private Connection connectToDatabase() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/book_inventory", "root", "nihalsql123@");
    }

    //now getting  connected database
    private List<Book> getDatabase() {
        List<Book> B_data = new ArrayList<>();
        try (Connection connection = connectToDatabase();
             Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM book_info");

            while (resultSet.next()) {
                String bookName = resultSet.getString("book_name");
                int bookID = resultSet.getInt("book_id");
                B_data.add(new Book(bookID, bookName));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return B_data;
    }

    //bar chart creating code
    private void getBarGraph() {
        List<Book> data = getDatabase();

        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("BAR-GRAPH");

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        for (Book entry : data) {
            series.getData().add(new XYChart.Data<>(entry.getBookName(), entry.getBookID()));
        }

        barChart.getData().add(series);

        //changing color of graph using CSS..
        String blueBarStyle = "-fx-bar-fill: blue;";
        for (XYChart.Data<String, Number> dataPoint : series.getData()) {
            dataPoint.getNode().setStyle(blueBarStyle);
        }

        Button switchToTableViewButton = new Button("Change To TableView");
        switchToTableViewButton.setOnAction(event -> getTableView());

       // VBox vbox = new VBox(barChart, switchToTableViewButton);


        VBox vbox = new VBox(barChart, switchToTableViewButton);
        Scene graphScene = new Scene(vbox, 700, 500);
        vbox.setAlignment(Pos.CENTER); // Center the contents within the VBox

        primaryStage.setTitle("Book Inventory List");
        primaryStage.setScene(graphScene);
        primaryStage.show();
    }

    //tableview creating code..
    private void getTableView() {
        List<Book> data = getDatabase();

        TableColumn<Book, String> nameColumn = new TableColumn<>("Book Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("bookName"));

        TableColumn<Book, Integer> gradeColumn = new TableColumn<>("Book Unique ID");
        gradeColumn.setCellValueFactory(new PropertyValueFactory<>("bookID"));

        TableView<Book> tableView = new TableView<>();
        tableView.getColumns().addAll(nameColumn, gradeColumn);
        tableView.getItems().addAll(data);

        Button switchToGraphButton = new Button("Go To Bar Chart");
        switchToGraphButton.setOnAction(event -> getBarGraph());

        VBox vbox = new VBox(tableView, switchToGraphButton);
        Scene tableViewScene = new Scene(vbox, 700, 500);
        vbox.setAlignment(Pos.CENTER); // Center the contents within the VBox

        primaryStage.setTitle("Book Inventory List");
        primaryStage.setScene(tableViewScene);
        primaryStage.show();
    }
}
