module com.example.nihalnihal {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.nihalnihal to javafx.fxml;
    exports com.example.nihalnihal;
}